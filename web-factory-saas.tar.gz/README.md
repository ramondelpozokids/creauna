# Web Factory SaaS

**The no-code website builder platform**

A modern SaaS platform to build, edit and publish professional websites — powered by AI and a beautiful drag-and-drop editor.

## 🚀 Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
app/
├── layout.tsx           # Root layout + metadata
├── page.tsx             # Landing page (marketing)
├── login/               # Login page (mock)
├── signup/              # Signup page (mock)
├── dashboard/           # Main dashboard with websites list
├── editor/[id]/         # Visual editor
├── preview/[id]/        # Full preview mode
├── templates/           # Template gallery
└── globals.css          # Tailwind + custom styles
```

## Features (Current)

- ✅ Beautiful marketing landing page
- ✅ Authentication pages (mock)
- ✅ Dashboard with websites management
- ✅ Drag-free visual editor (block-based)
- ✅ AI-ready buttons (placeholder)
- ✅ Template gallery
- ✅ Live preview
- ✅ Responsive design
- ✅ Full TypeScript + Next.js 16 + Tailwind 4

## Next steps (ideas)

- Add real auth (Clerk / NextAuth / Supabase)
- Add Prisma + database (websites, users, blocks)
- Improve editor with real drag & drop
- Add AI website generator
- Add publishing & custom domains
- Add billing (Stripe)
- Add more block types + rich content

## Commands

| Command       | Description         |
|---------------|---------------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run start` | Start production server |

---

Built with ❤️ using Next.js 16
