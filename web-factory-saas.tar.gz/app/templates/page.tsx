'use client';

import Link from 'next/link';

const templates = [
  { id: 1, name: "SaaS Landing", category: "Startup", color: "from-blue-500 to-indigo-600" },
  { id: 2, name: "Portfolio", category: "Creative", color: "from-violet-500 to-fuchsia-600" },
  { id: 3, name: "Ecommerce Store", category: "Ecommerce", color: "from-emerald-500 to-teal-600" },
  { id: 4, name: "Agency", category: "Business", color: "from-orange-500 to-rose-600" },
  { id: 5, name: "Restaurant", category: "Food", color: "from-amber-500 to-yellow-600" },
  { id: 6, name: "Blog & Magazine", category: "Content", color: "from-slate-500 to-zinc-600" },
  { id: 7, name: "Real Estate", category: "Business", color: "from-cyan-500 to-blue-600" },
  { id: 8, name: "Event Landing", category: "Events", color: "from-purple-500 to-pink-600" },
];

export default function Templates() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container py-10">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Templates</h1>
            <p className="text-gray-600 mt-1">Choose from 150+ beautiful professional templates</p>
          </div>
          <Link href="/dashboard" className="text-sm">← Back to dashboard</Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {templates.map((template) => (
            <div key={template.id} className="group cursor-pointer">
              <div className={`aspect-video bg-gradient-to-br ${template.color} rounded-2xl mb-4 flex items-end p-6 relative overflow-hidden shadow`}>
                <div className="text-white">
                  <div className="font-semibold text-xl">{template.name}</div>
                  <div className="text-white/70 text-sm">{template.category}</div>
                </div>
                
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all" />
                
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition">
                  <div className="bg-white text-xs px-3 py-1 rounded-full font-medium text-gray-800 shadow">
                    Use template
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium">{template.name}</div>
                  <div className="text-sm text-gray-600">{template.category}</div>
                </div>
                <button 
                  onClick={() => {
                    // Simulate creating new site from template
                    alert(`Creating website from "${template.name}" template...`);
                    window.location.href = '/dashboard';
                  }}
                  className="text-xs px-4 py-1.5 bg-blue-600 text-white rounded-lg font-medium"
                >
                  Use
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-gray-500">More templates coming soon. <a href="#" className="text-blue-600">Request a template</a></p>
        </div>
      </div>
    </div>
  );
}
