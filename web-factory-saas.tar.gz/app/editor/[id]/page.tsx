'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';

interface Block {
  id: number;
  type: string;
  content: string;
}

export default function Editor() {
  const params = useParams();
  const websiteId = params.id;

  const [blocks, setBlocks] = useState<Block[]>([
    { id: 1, type: 'hero', content: 'Welcome to my website' },
    { id: 2, type: 'text', content: 'This is a powerful no-code editor. Drag and drop blocks here.' },
    { id: 3, type: 'cta', content: 'Get started' },
  ]);

  const [selectedBlock, setSelectedBlock] = useState<number | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [websiteName, setWebsiteName] = useState('My New Website');

  const addBlock = (type: string) => {
    const newBlock: Block = {
      id: Date.now(),
      type,
      content: type === 'hero' ? 'New Hero Title' : type === 'cta' ? 'Click here' : 'New text content',
    };
    setBlocks([...blocks, newBlock]);
  };

  const updateBlock = (id: number, newContent: string) => {
    setBlocks(blocks.map(block => 
      block.id === id ? { ...block, content: newContent } : block
    ));
  };

  const deleteBlock = (id: number) => {
    setBlocks(blocks.filter(b => b.id !== id));
    setSelectedBlock(null);
  };

  const publishSite = () => {
    alert('Website published successfully! (Mock)');
    // In real app: call API
  };

  return (
    <div className="flex h-screen bg-white">
      {/* Sidebar - Blocks */}
      <div className="w-72 border-r bg-gray-50 flex flex-col">
        <div className="p-4 border-b bg-white">
          <Link href="/dashboard" className="text-sm text-blue-600 flex items-center gap-1">
            ← Back to dashboard
          </Link>
          <div className="mt-2">
            <input 
              type="text" 
              value={websiteName}
              onChange={(e) => setWebsiteName(e.target.value)}
              className="font-semibold text-xl w-full bg-transparent border-b border-gray-200 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="p-4 flex-1 overflow-y-auto">
          <div className="text-xs uppercase tracking-widest text-gray-500 mb-3 font-medium">Add blocks</div>
          
          <div className="space-y-1">
            {[
              { type: 'hero', label: 'Hero Section', icon: '🖼️' },
              { type: 'text', label: 'Text Block', icon: '📝' },
              { type: 'image', label: 'Image', icon: '🖼️' },
              { type: 'cta', label: 'Call to Action', icon: '🎯' },
              { type: 'features', label: 'Features', icon: '✨' },
              { type: 'testimonial', label: 'Testimonial', icon: '💬' },
              { type: 'pricing', label: 'Pricing Table', icon: '💰' },
            ].map((blockType) => (
              <button
                key={blockType.type}
                onClick={() => addBlock(blockType.type)}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left hover:bg-white transition text-sm"
              >
                <span>{blockType.icon}</span>
                <span>{blockType.label}</span>
              </button>
            ))}
          </div>

          <div className="mt-8 pt-4 border-t">
            <div className="text-xs uppercase tracking-widest text-gray-500 mb-3 font-medium">AI Tools</div>
            <button className="w-full flex items-center gap-3 px-4 py-3 text-sm rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
              ✨ Generate with AI
            </button>
            <button className="mt-2 w-full text-sm px-4 py-2.5 text-left hover:bg-white rounded-xl">
              Improve current page
            </button>
          </div>
        </div>

        <div className="p-4 border-t bg-white">
          <button 
            onClick={publishSite}
            className="btn-primary w-full"
          >
            Publish Website
          </button>
          <p className="text-[10px] text-center text-gray-500 mt-2">Changes saved automatically</p>
        </div>
      </div>

      {/* Main Canvas */}
      <div className="flex-1 flex flex-col">
        {/* Top Toolbar */}
        <div className="h-14 border-b flex items-center justify-between px-6 bg-white">
          <div className="flex items-center gap-4 text-sm">
            <span className="font-medium">Editor</span>
            <div className="px-2 py-0.5 text-xs bg-green-100 text-green-700 rounded">Live preview</div>
          </div>

          <div className="flex items-center gap-3 text-sm">
            <button 
              onClick={() => setShowPreview(!showPreview)}
              className="px-4 py-1.5 rounded-lg border text-sm font-medium"
            >
              {showPreview ? 'Hide Preview' : 'Show Preview'}
            </button>
            <Link href={`/preview/${websiteId}`} className="px-4 py-1.5 rounded-lg bg-gray-900 text-white text-sm font-medium">
              Full Preview
            </Link>
            <button className="px-4 py-1.5 text-sm border rounded-lg">Save</button>
          </div>
        </div>

        {/* Canvas */}
        <div className="flex-1 bg-gray-100 overflow-auto p-8 flex justify-center">
          <div className="w-full max-w-4xl bg-white shadow-xl rounded-2xl min-h-[700px] p-8 border">
            <div className="flex items-center justify-between mb-8">
              <div>
                <div className="text-xs uppercase tracking-widest text-gray-500">Preview</div>
                <h1 className="text-3xl font-semibold">{websiteName}</h1>
              </div>
              <div className="text-xs px-3 py-1 bg-gray-100 rounded-full">Desktop</div>
            </div>

            {/* Blocks */}
            <div className="space-y-4">
              {blocks.length === 0 && (
                <div className="text-center py-20 text-gray-400">
                  No blocks yet. Add some from the sidebar.
                </div>
              )}

              {blocks.map((block, index) => (
                <div 
                  key={block.id}
                  onClick={() => setSelectedBlock(block.id)}
                  className={`group relative border-2 p-6 rounded-2xl transition cursor-pointer ${
                    selectedBlock === block.id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-xs uppercase text-gray-500 mb-1">{block.type}</div>
                  
                  {block.type === 'hero' && (
                    <div>
                      <div className="text-4xl font-semibold">{block.content}</div>
                      <div className="mt-3 text-gray-600">Your hero subtitle goes here.</div>
                    </div>
                  )}

                  {block.type === 'text' && (
                    <div className="text-xl leading-relaxed text-gray-700">{block.content}</div>
                  )}

                  {block.type === 'cta' && (
                    <div>
                      <div className="inline-block px-8 py-3 rounded-xl bg-blue-600 text-white font-medium">{block.content}</div>
                    </div>
                  )}

                  {block.type === 'features' && (
                    <div>
                      <h3 className="font-semibold mb-2">Our Features</h3>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        {['Fast', 'Secure', 'Easy'].map((f, i) => <div key={i} className="p-4 border rounded">{f}</div>)}
                      </div>
                    </div>
                  )}

                  {block.type === 'testimonial' && (
                    <div className="italic">"This tool is amazing!" — Happy customer</div>
                  )}

                  {/* Block controls */}
                  {selectedBlock === block.id && (
                    <div className="absolute -top-3 right-3 flex gap-1 bg-white border rounded-lg p-1 shadow">
                      <button onClick={(e) => { e.stopPropagation(); deleteBlock(block.id); }} className="px-2 text-xs text-red-600 hover:bg-red-50 rounded">Delete</button>
                    </div>
                  )}

                  {selectedBlock === block.id && (
                    <div className="mt-4 pt-4 border-t">
                      <input
                        type="text"
                        value={block.content}
                        onChange={(e) => updateBlock(block.id, e.target.value)}
                        className="w-full border px-3 py-2 rounded text-sm"
                        onClick={e => e.stopPropagation()}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Properties */}
      {selectedBlock && (
        <div className="w-80 border-l bg-gray-50 p-4 overflow-auto">
          <div className="font-semibold mb-4">Block Properties</div>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium block mb-1">Block Type</label>
              <div className="px-3 py-2 bg-white border rounded text-sm">
                {blocks.find(b => b.id === selectedBlock)?.type}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium block mb-1">Content</label>
              <textarea 
                value={blocks.find(b => b.id === selectedBlock)?.content} 
                onChange={(e) => {
                  const block = blocks.find(b => b.id === selectedBlock);
                  if (block) updateBlock(block.id, e.target.value);
                }}
                className="w-full h-20 border px-3 py-2 rounded text-sm resize-y"
              />
            </div>

            <div>
              <label className="text-sm font-medium block mb-1">Style</label>
              <select className="w-full border px-3 py-2 rounded text-sm">
                <option>Default</option>
                <option>Accent</option>
                <option>Minimal</option>
              </select>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t">
            <button 
              onClick={() => setSelectedBlock(null)}
              className="text-sm text-blue-600"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
