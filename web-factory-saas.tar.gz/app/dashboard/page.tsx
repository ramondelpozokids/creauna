'use client';

import Link from 'next/link';
import { useState } from 'react';

interface Website {
  id: number;
  name: string;
  url: string;
  status: 'published' | 'draft';
  lastUpdated: string;
  template: string;
}

export default function Dashboard() {
  const [websites, setWebsites] = useState<Website[]>([
    {
      id: 1,
      name: "Acme Landing",
      url: "acme.webfactory.app",
      status: "published",
      lastUpdated: "2 hours ago",
      template: "SaaS Landing"
    },
    {
      id: 2,
      name: "Portfolio Site",
      url: "maria-portfolio.webfactory.app",
      status: "published",
      lastUpdated: "Yesterday",
      template: "Portfolio"
    },
    {
      id: 3,
      name: "New Project",
      url: "",
      status: "draft",
      lastUpdated: "10 minutes ago",
      template: "Agency"
    },
  ]);

  const [showNewModal, setShowNewModal] = useState(false);
  const [newWebsiteName, setNewWebsiteName] = useState('');

  const createWebsite = () => {
    if (!newWebsiteName.trim()) return;

    const newSite: Website = {
      id: Date.now(),
      name: newWebsiteName,
      url: "",
      status: "draft",
      lastUpdated: "Just now",
      template: "Blank"
    };

    setWebsites([newSite, ...websites]);
    setNewWebsiteName('');
    setShowNewModal(false);

    // Redirect to editor
    window.location.href = `/editor/${newSite.id}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Top Navbar */}
      <nav className="border-b bg-white dark:bg-gray-900 sticky top-0 z-40">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">WF</span>
              </div>
              <span className="font-semibold">Web Factory</span>
            </Link>

            <div className="hidden md:flex items-center gap-6 text-sm">
              <Link href="/dashboard" className="font-medium text-blue-600">Dashboard</Link>
              <Link href="/templates" className="hover:text-blue-600">Templates</Link>
              <Link href="/projects" className="hover:text-blue-600">Projects</Link>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-medium">JD</div>
              <span className="hidden md:block">John Doe</span>
            </div>
            
            <Link href="/settings" className="text-sm px-3 py-1.5 hover:bg-gray-100 rounded-lg">Settings</Link>
          </div>
        </div>
      </nav>

      <div className="container py-8">
        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-gray-600 mt-1">Welcome back, John. You have 3 active websites.</p>
          </div>

          <button 
            onClick={() => setShowNewModal(true)}
            className="btn-primary flex items-center gap-2 px-6"
          >
            <span>+</span> 
            New Website
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Websites", value: "12" },
            { label: "Published", value: "9" },
            { label: "Monthly Visitors", value: "128k" },
            { label: "Conversions", value: "4.2k" },
          ].map((stat, i) => (
            <div key={i} className="card py-4">
              <div className="text-sm text-gray-600">{stat.label}</div>
              <div className="text-3xl font-semibold mt-1">{stat.value}</div>
            </div>
          ))}
        </div>

        {/* Websites Table */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Your Websites</h2>
            <Link href="/templates" className="text-sm text-blue-600 hover:underline">Browse templates →</Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-gray-600">
                  <th className="pb-3 font-medium">Website</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Template</th>
                  <th className="pb-3 font-medium">Last updated</th>
                  <th className="pb-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {websites.map((site) => (
                  <tr key={site.id} className="border-b last:border-none hover:bg-gray-50 dark:hover:bg-gray-900">
                    <td className="py-4">
                      <div>
                        <div className="font-medium">{site.name}</div>
                        {site.url ? (
                          <a href={`https://${site.url}`} target="_blank" className="text-xs text-blue-600 hover:underline">
                            {site.url}
                          </a>
                        ) : (
                          <span className="text-xs text-gray-500">Not published</span>
                        )}
                      </div>
                    </td>
                    <td className="py-4">
                      <span className={`inline-flex items-center px-3 py-0.5 text-xs font-medium rounded-full ${
                        site.status === 'published' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {site.status}
                      </span>
                    </td>
                    <td className="py-4 text-gray-600">{site.template}</td>
                    <td className="py-4 text-gray-600">{site.lastUpdated}</td>
                    <td className="py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {site.status === 'draft' ? (
                          <Link 
                            href={`/editor/${site.id}`} 
                            className="px-4 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                          >
                            Edit
                          </Link>
                        ) : (
                          <>
                            <a href={`https://${site.url}`} target="_blank" className="px-4 py-1.5 text-xs font-medium border rounded-lg hover:bg-gray-100 transition">Visit</a>
                            <Link href={`/editor/${site.id}`} className="px-4 py-1.5 text-xs font-medium border rounded-lg hover:bg-gray-100 transition">Edit</Link>
                          </>
                        )}
                        <button className="px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg">Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* New Website Modal */}
      {showNewModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-900 rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-semibold mb-4">Create new website</h2>
            
            <input
              type="text"
              value={newWebsiteName}
              onChange={(e) => setNewWebsiteName(e.target.value)}
              placeholder="My awesome website"
              className="w-full border px-4 py-3 rounded-xl focus:ring-2 focus:ring-blue-500 mb-6"
              autoFocus
            />

            <div className="flex gap-3">
              <button 
                onClick={() => setShowNewModal(false)}
                className="flex-1 py-3 border rounded-xl font-medium"
              >
                Cancel
              </button>
              <button 
                onClick={createWebsite}
                disabled={!newWebsiteName.trim()}
                className="flex-1 py-3 bg-blue-600 text-white font-medium rounded-xl disabled:opacity-50"
              >
                Create website
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
