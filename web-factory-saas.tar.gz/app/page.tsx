import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-950 dark:to-gray-900">
      {/* Navbar */}
      <nav className="border-b bg-white/80 dark:bg-gray-950/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">WF</span>
            </div>
            <span className="text-xl font-semibold">Web Factory</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium">
            <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
            <a href="#templates" className="hover:text-blue-600 transition-colors">Templates</a>
            <a href="#pricing" className="hover:text-blue-600 transition-colors">Pricing</a>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm font-medium hover:text-blue-600">
              Log in
            </Link>
            <Link href="/signup" className="btn-primary text-sm px-5 py-2">
              Start for free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="container pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 bg-blue-50 dark:bg-blue-950 text-blue-600 px-4 py-1 rounded-full text-sm font-medium mb-6">
          🚀 Now with AI-powered website generation
        </div>
        
        <h1 className="text-6xl font-bold tracking-tighter mb-6">
          Build stunning websites.<br />In minutes.
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-8">
          The all-in-one no-code platform to create, launch and manage professional websites. 
          Perfect for agencies, freelancers, and businesses.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/signup" className="btn-primary px-8 py-3 text-base">
            Get started for free
          </Link>
          <a href="#demo" className="btn-secondary px-8 py-3 text-base">
            Watch demo
          </a>
        </div>

        <div className="mt-6 text-sm text-gray-500">
          No credit card required • Free plan available
        </div>
      </div>

      {/* Stats */}
      <div className="container pb-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: "38k+", label: "Websites created" },
            { number: "4.9", label: "Average rating" },
            { number: "92k+", label: "Users" },
            { number: "190+", label: "Countries" },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-bold text-blue-600">{stat.number}</div>
              <div className="text-gray-500 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div id="features" className="container py-16 border-t">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-semibold tracking-tight">Everything you need to build websites</h2>
          <p className="text-gray-600 mt-3">Powerful features for modern web builders.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: "⚡",
              title: "AI Website Builder",
              desc: "Describe your site and our AI will generate a beautiful, responsive website in seconds."
            },
            {
              icon: "🎨",
              title: "Drag & Drop Editor",
              desc: "Full visual editor with 200+ blocks, animations, and responsive controls."
            },
            {
              icon: "🔗",
              title: "Integrations",
              desc: "Connect with Stripe, Mailchimp, Google Analytics, Zapier and more."
            },
            {
              icon: "📱",
              title: "Mobile Optimized",
              desc: "Every site is automatically optimized for mobile, tablet and desktop."
            },
            {
              icon: "🔒",
              title: "Enterprise Security",
              desc: "SOC 2 compliant, built-in SSL, GDPR tools and custom domains."
            },
            {
              icon: "📊",
              title: "Analytics & SEO",
              desc: "Built-in SEO tools, performance monitoring and conversion analytics."
            },
          ].map((feature, i) => (
            <div key={i} className="card">
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="font-semibold text-xl mb-2">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Templates Section */}
      <div id="templates" className="bg-gray-50 dark:bg-gray-900 py-16">
        <div className="container">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-4xl font-semibold tracking-tight">Start with beautiful templates</h2>
              <p className="text-gray-600">Over 150 professional templates ready to customize.</p>
            </div>
            <Link href="/templates" className="text-blue-600 font-medium flex items-center gap-1">
              Browse all → 
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {["SaaS Landing", "Portfolio", "Ecommerce", "Agency", "Restaurant", "Blog", "Startup", "Real Estate"].map((t, i) => (
              <div key={i} className="group relative aspect-video bg-white rounded-2xl overflow-hidden border shadow-sm hover:shadow-xl transition-all cursor-pointer">
                <div className="absolute inset-0 bg-gradient-to-br from-gray-900/70 to-transparent flex items-end p-5">
                  <div>
                    <div className="text-white text-lg font-medium">{t}</div>
                    <div className="text-white/70 text-xs">Professional • Ready to launch</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing */}
      <div id="pricing" className="container py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-semibold tracking-tight">Simple pricing for everyone</h2>
          <p className="text-gray-600">Start free. Scale as you grow.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[
            { name: "Starter", price: "0", features: ["3 Websites", "Basic templates", "Community support", "Custom domain"], popular: false },
            { name: "Pro", price: "29", features: ["Unlimited websites", "All templates", "AI generator", "Priority support", "Remove branding"], popular: true },
            { name: "Business", price: "79", features: ["Everything in Pro", "Team collaboration", "Advanced analytics", "Custom integrations", "Dedicated manager"], popular: false },
          ].map((plan, idx) => (
            <div key={idx} className={`card relative ${plan.popular ? 'ring-2 ring-blue-600' : ''}`}>
              {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs px-4 py-0.5 rounded-full font-medium">MOST POPULAR</div>}
              <div className="mb-6">
                <div className="font-medium text-lg">{plan.name}</div>
                <div className="mt-3 flex items-baseline">
                  <span className="text-5xl font-semibold">${plan.price}</span>
                  <span className="text-gray-500 ml-1">/mo</span>
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <span className="text-green-600">✓</span> {f}
                  </li>
                ))}
              </ul>
              <Link href="/signup" className={plan.popular ? "btn-primary w-full text-center block" : "btn-secondary w-full text-center block"}>
                {plan.price === "0" ? "Start for free" : "Get started"}
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="container pb-16">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-3xl p-12 text-center">
          <h2 className="text-4xl font-semibold tracking-tight mb-3">Ready to launch your next website?</h2>
          <p className="text-blue-100 mb-8">Join thousands of creators building with Web Factory today.</p>
          <Link href="/signup" className="inline-block bg-white text-blue-600 px-8 py-3 rounded-xl font-semibold hover:bg-gray-100 transition">
            Start building for free
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t py-12 text-sm text-gray-500">
        <div className="container flex flex-col md:flex-row justify-between items-center gap-y-4">
          <div>© {new Date().getFullYear()} Web Factory. All rights reserved.</div>
          <div className="flex gap-6">
            <a href="#">About</a>
            <a href="#">Blog</a>
            <a href="#">Changelog</a>
            <a href="#">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
