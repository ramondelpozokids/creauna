'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';

export default function Preview() {
  const params = useParams();
  const id = params.id;

  return (
    <div className="min-h-screen bg-white">
      {/* Preview Header */}
      <div className="border-b bg-white sticky top-0 z-50">
        <div className="container flex items-center justify-between h-14">
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="text-sm flex items-center gap-1.5 text-gray-600 hover:text-black">
              ← Dashboard
            </Link>
            <div className="text-sm font-medium">Preview Mode</div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded">Published</div>
            <Link href={`/editor/${id}`} className="px-4 py-1.5 text-sm font-medium bg-blue-600 text-white rounded-lg">
              Edit site
            </Link>
          </div>
        </div>
      </div>

      {/* Live Preview */}
      <div className="container py-10">
        <div className="max-w-5xl mx-auto">
          <div className="bg-gray-100 rounded-2xl p-8">
            <h1 className="text-5xl font-bold mb-6">Welcome to your website!</h1>
            <p className="text-xl text-gray-600 max-w-lg">This is a live preview of the site you&apos;re building in Web Factory.</p>
            
            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl p-6 shadow-sm border">
                  <div className="h-3 w-20 bg-blue-600 rounded mb-3"></div>
                  <div className="text-lg font-semibold">Feature {i + 1}</div>
                  <div className="text-sm mt-2 text-gray-500">This is placeholder content from the editor.</div>
                </div>
              ))}
            </div>

            <div className="mt-10 flex gap-4">
              <div className="px-7 py-3 bg-blue-600 text-white rounded-xl font-medium">Get started</div>
              <div className="px-7 py-3 border rounded-xl">Learn more</div>
            </div>
          </div>
        </div>
      </div>

      <div className="container text-center py-10 text-sm text-gray-400">
        This is a preview. Real sites will have your actual content, images, and design.
      </div>
    </div>
  );
}
